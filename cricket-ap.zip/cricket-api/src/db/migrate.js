import { getPool } from '../lib/db.js';
import config from '../config/index.js';
import logger from '../lib/logger.js';

const TABLES = [
  // ====================================================
  // TEAMS
  // ====================================================
  `CREATE TABLE IF NOT EXISTS teams (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    external_id   VARCHAR(50) UNIQUE,
    name          VARCHAR(200) NOT NULL,
    short_name    VARCHAR(20),
    logo_url      TEXT,
    country       VARCHAR(100),
    team_type     VARCHAR(20) DEFAULT 'international',
    metadata      JSON,
    created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_teams_external (external_id),
    INDEX idx_teams_name (name)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

  // ====================================================
  // PLAYERS
  // ====================================================
  `CREATE TABLE IF NOT EXISTS players (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    external_id   VARCHAR(50) UNIQUE,
    name          VARCHAR(200) NOT NULL,
    full_name     VARCHAR(300),
    dob           DATE,
    nationality   VARCHAR(100),
    role          VARCHAR(50),
    batting_style VARCHAR(50),
    bowling_style VARCHAR(100),
    image_url     TEXT,
    team_id       INT,
    stats         JSON,
    metadata      JSON,
    created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_players_external (external_id),
    INDEX idx_players_team (team_id),
    INDEX idx_players_name (name),
    FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

  // ====================================================
  // SERIES
  // ====================================================
  `CREATE TABLE IF NOT EXISTS series (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    external_id   VARCHAR(50) UNIQUE,
    name          VARCHAR(300) NOT NULL,
    short_name    VARCHAR(100),
    season        VARCHAR(20),
    start_date    DATE,
    end_date      DATE,
    series_type   VARCHAR(30),
    format        VARCHAR(20),
    country       VARCHAR(100),
    metadata      JSON,
    created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_series_external (external_id),
    INDEX idx_series_dates (start_date, end_date)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

  // ====================================================
  // MATCHES
  // ====================================================
  `CREATE TABLE IF NOT EXISTS matches (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    external_id     VARCHAR(50) UNIQUE,
    series_id       INT,
    match_format    VARCHAR(20) NOT NULL,
    match_type      VARCHAR(30),
    status          VARCHAR(30) NOT NULL DEFAULT 'upcoming',
    status_text     TEXT,
    team1_id        INT,
    team2_id        INT,
    venue           VARCHAR(300),
    city            VARCHAR(100),
    country         VARCHAR(100),
    start_time      DATETIME,
    end_time        DATETIME,
    toss_winner_id  INT,
    toss_decision   VARCHAR(10),
    winner_id       INT,
    result_text     TEXT,
    man_of_match_id INT,
    current_innings INT DEFAULT 0,
    day_number      INT,
    session         VARCHAR(20),
    live_score      JSON,
    metadata        JSON,
    provider        VARCHAR(30) DEFAULT 'cricbuzz',
    last_polled_at  DATETIME,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_matches_external (external_id),
    INDEX idx_matches_status (status),
    INDEX idx_matches_series (series_id),
    INDEX idx_matches_start (start_time),
    INDEX idx_matches_teams (team1_id, team2_id),
    FOREIGN KEY (series_id) REFERENCES series(id) ON DELETE SET NULL,
    FOREIGN KEY (team1_id) REFERENCES teams(id) ON DELETE SET NULL,
    FOREIGN KEY (team2_id) REFERENCES teams(id) ON DELETE SET NULL,
    FOREIGN KEY (toss_winner_id) REFERENCES teams(id) ON DELETE SET NULL,
    FOREIGN KEY (winner_id) REFERENCES teams(id) ON DELETE SET NULL,
    FOREIGN KEY (man_of_match_id) REFERENCES players(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

  // ====================================================
  // INNINGS
  // ====================================================
  `CREATE TABLE IF NOT EXISTS innings (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    match_id        INT NOT NULL,
    innings_number  INT NOT NULL,
    batting_team_id INT,
    bowling_team_id INT,
    total_runs      INT DEFAULT 0,
    total_wickets   INT DEFAULT 0,
    total_overs     DECIMAL(5,1) DEFAULT 0,
    target          INT,
    run_rate        DECIMAL(5,2),
    required_rate   DECIMAL(5,2),
    is_completed    TINYINT(1) DEFAULT 0,
    extras          JSON,
    fow             JSON,
    metadata        JSON,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_innings (match_id, innings_number),
    INDEX idx_innings_match (match_id),
    FOREIGN KEY (match_id) REFERENCES matches(id) ON DELETE CASCADE,
    FOREIGN KEY (batting_team_id) REFERENCES teams(id) ON DELETE SET NULL,
    FOREIGN KEY (bowling_team_id) REFERENCES teams(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

  // ====================================================
  // BATTING SCORECARDS
  // ====================================================
  `CREATE TABLE IF NOT EXISTS batting_scores (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    innings_id      INT NOT NULL,
    player_id       INT,
    player_name     VARCHAR(200),
    batting_pos     INT,
    runs            INT DEFAULT 0,
    balls           INT DEFAULT 0,
    fours           INT DEFAULT 0,
    sixes           INT DEFAULT 0,
    strike_rate     DECIMAL(6,2),
    dismissal_type  VARCHAR(50),
    dismissal_text  TEXT,
    bowler_id       INT,
    fielder_id      INT,
    is_batting      TINYINT(1) DEFAULT 0,
    is_striker      TINYINT(1) DEFAULT 0,
    minutes         INT,
    metadata        JSON,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_batting_innings (innings_id),
    INDEX idx_batting_player (player_id),
    FOREIGN KEY (innings_id) REFERENCES innings(id) ON DELETE CASCADE,
    FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE SET NULL,
    FOREIGN KEY (bowler_id) REFERENCES players(id) ON DELETE SET NULL,
    FOREIGN KEY (fielder_id) REFERENCES players(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

  // ====================================================
  // BOWLING SCORECARDS
  // ====================================================
  `CREATE TABLE IF NOT EXISTS bowling_scores (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    innings_id      INT NOT NULL,
    player_id       INT,
    player_name     VARCHAR(200),
    overs           DECIMAL(5,1) DEFAULT 0,
    maidens         INT DEFAULT 0,
    runs_conceded   INT DEFAULT 0,
    wickets         INT DEFAULT 0,
    economy         DECIMAL(5,2),
    dots            INT DEFAULT 0,
    fours_conceded  INT DEFAULT 0,
    sixes_conceded  INT DEFAULT 0,
    wides           INT DEFAULT 0,
    no_balls        INT DEFAULT 0,
    is_bowling      TINYINT(1) DEFAULT 0,
    metadata        JSON,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_bowling_innings (innings_id),
    INDEX idx_bowling_player (player_id),
    FOREIGN KEY (innings_id) REFERENCES innings(id) ON DELETE CASCADE,
    FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

  // ====================================================
  // COMMENTARY
  // ====================================================
  `CREATE TABLE IF NOT EXISTS commentary (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    match_id        INT NOT NULL,
    innings_number  INT,
    over_number     DECIMAL(5,1),
    ball_number     INT,
    event_type      VARCHAR(30),
    commentary_text TEXT NOT NULL,
    runs            INT DEFAULT 0,
    is_wicket       TINYINT(1) DEFAULT 0,
    is_boundary     TINYINT(1) DEFAULT 0,
    batsman_name    VARCHAR(200),
    bowler_name     VARCHAR(200),
    timestamp       BIGINT,
    metadata        JSON,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_commentary_match (match_id),
    INDEX idx_commentary_match_innings (match_id, innings_number),
    INDEX idx_commentary_timestamp (match_id, timestamp),
    FOREIGN KEY (match_id) REFERENCES matches(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

  // ====================================================
  // POINTS TABLES
  // ====================================================
  `CREATE TABLE IF NOT EXISTS points_table (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    series_id       INT NOT NULL,
    team_id         INT,
    team_name       VARCHAR(200),
    matches_played  INT DEFAULT 0,
    wins            INT DEFAULT 0,
    losses          INT DEFAULT 0,
    ties            INT DEFAULT 0,
    no_results      INT DEFAULT 0,
    points          INT DEFAULT 0,
    nrr             DECIMAL(6,3) DEFAULT 0,
    position        INT,
    group_name      VARCHAR(50),
    is_qualified    TINYINT(1) DEFAULT 0,
    metadata        JSON,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_points (series_id, team_id),
    INDEX idx_points_series (series_id),
    FOREIGN KEY (series_id) REFERENCES series(id) ON DELETE CASCADE,
    FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

  // ====================================================
  // API KEYS
  // ====================================================
  `CREATE TABLE IF NOT EXISTS api_keys (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    key_hash        VARCHAR(128) UNIQUE NOT NULL,
    name            VARCHAR(200) NOT NULL,
    email           VARCHAR(300),
    tier            VARCHAR(20) DEFAULT 'free',
    rate_limit      INT DEFAULT 100,
    is_active       TINYINT(1) DEFAULT 1,
    last_used_at    DATETIME,
    expires_at      DATETIME,
    metadata        JSON,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_api_keys_hash (key_hash)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,

  // ====================================================
  // USERS (admin panel)
  // ====================================================
  `CREATE TABLE IF NOT EXISTS users (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    username        VARCHAR(100) UNIQUE NOT NULL,
    email           VARCHAR(300) UNIQUE NOT NULL,
    password_hash   VARCHAR(200) NOT NULL,
    role            VARCHAR(20) DEFAULT 'user',
    is_active       TINYINT(1) DEFAULT 1,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
];

async function migrate() {
  const pool = getPool();
  try {
    logger.info('Running database migration...');
    logger.info(`Connecting to MySQL: ${config.db.user}@${config.db.host}:${config.db.port}/${config.db.database}`);

    for (const sql of TABLES) {
      await pool.execute(sql);
    }

    logger.info(`Database migration completed successfully (${TABLES.length} tables)`);
  } catch (err) {
    logger.error(`Migration failed: ${err.message || err.toString()}`);
    logger.error(`Error detail: ${JSON.stringify({ code: err.code, errno: err.errno, sqlState: err.sqlState, sqlMessage: err.sqlMessage })}`);
    throw err;
  } finally {
    await pool.end();
  }
}

migrate().catch((err) => {
  console.error('Migration error:', err.message || err);
  process.exit(1);
});
