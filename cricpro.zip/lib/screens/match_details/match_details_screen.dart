import 'package:flutter/material.dart';

import '../../app_theme.dart';
import '../../components.dart';
import '../../screens.dart';

class MatchDetailsScreen extends StatefulWidget {
  const MatchDetailsScreen({super.key, this.onWatchLive});

  final VoidCallback? onWatchLive;

  @override
  State<MatchDetailsScreen> createState() => _MatchDetailsScreenState();
}

class _MatchDetailsScreenState extends State<MatchDetailsScreen> {
  int tab = 0;

  @override
  Widget build(BuildContext context) {
    final c = context.cric;
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(gradient: c.bgGradient),
        child: SafeArea(
          child: ListView(
            padding: EdgeInsets.fromLTRB(context.horizontalPadding, 18, context.horizontalPadding, context.detailBottomPadding),
            children: [
              AppHeader(
                leading: IconButton(onPressed: () => Navigator.pop(context), icon: Icon(Icons.arrow_back_rounded, color: c.text)),
                title: 'Match Details',
                trailing: [
                  GlowIconButton(icon: Icons.search_rounded),
                  const SizedBox(width: 8),
                  GlowIconButton(icon: Icons.filter_alt_outlined),
                ],
              ),
              const SizedBox(height: 16),
              MatchDetailHeroCard(onWatchLive: widget.onWatchLive),
              const SizedBox(height: 16),
              SegmentedTabs(
                items: const [
                  ('Scorecard', null),
                  ('Commentary', null),
                  ('Overs', null),
                  ('Info', null),
                  ('Squads', null),
                ],
                selected: tab,
                onChanged: (v) => setState(() => tab = v),
                height: 58,
              ),
              const SizedBox(height: 16),
              if (tab == 0) const MatchScorecardTab(),
              if (tab == 1) const MatchCommentaryTab(),
              if (tab == 2) const MatchOversTab(),
              if (tab == 3) const MatchInfoTab(),
              if (tab == 4) const MatchSquadsTab(),
            ],
          ),
        ),
      ),
    );
  }
}
