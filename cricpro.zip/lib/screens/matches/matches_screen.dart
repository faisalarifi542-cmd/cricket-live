import 'package:flutter/material.dart';
import '../../app_theme.dart';
import '../../components.dart';
import '../../models.dart';
import '../../screens.dart';

class MatchesScreen extends StatefulWidget {
  const MatchesScreen({
    super.key,
    required this.onOpenMatch,
    required this.onOpenSearch,
    required this.onOpenFilters,
    required this.onOpenReminders,
    required this.onOpenSeries,
  });

  final VoidCallback onOpenMatch;
  final VoidCallback onOpenSearch;
  final VoidCallback onOpenFilters;
  final VoidCallback onOpenReminders;
  final VoidCallback onOpenSeries;

  @override
  State<MatchesScreen> createState() => _MatchesScreenState();
}

class _MatchesScreenState extends State<MatchesScreen> {
  int topTab = 1;
  int category = 0;

  @override
  Widget build(BuildContext context) {
    final c = context.cric;
    final filters = ['All', 'International', 'League', 'Domestic'];
    final list = topTab == 2 ? AppData.matchesFinished : AppData.matchesUpcoming;
    return Container(
      decoration: BoxDecoration(gradient: c.bgGradient),
      child: SafeArea(
        child: ListView(
          padding: EdgeInsets.fromLTRB(context.horizontalPadding, 18, context.horizontalPadding, context.mainBottomPadding),
          children: [
            AppHeader(
              showLogo: true,
              trailing: [
                GlowIconButton(icon: Icons.search_rounded, onTap: widget.onOpenSearch),
                const SizedBox(width: 8),
                GlowIconButton(icon: Icons.filter_alt_outlined, onTap: widget.onOpenFilters),
              ],
            ),
            const SizedBox(height: 22),
            SegmentedTabs(
              items: const [
                ('Live', Icons.podcasts_rounded),
                ('Upcoming', Icons.calendar_month_rounded),
                ('Finished', Icons.check_circle_outline_rounded),
              ],
              selected: topTab,
              onChanged: (v) => setState(() => topTab = v),
            ),
            const SizedBox(height: 18),
            SizedBox(
              height: 46,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemBuilder: (_, i) => PillChip(filters[i], selected: category == i, onTap: () => setState(() => category = i)),
                separatorBuilder: (_, __) => const SizedBox(width: 12),
                itemCount: filters.length,
              ),
            ),
            const SizedBox(height: 22),
            for (final item in list)
              Padding(
                padding: const EdgeInsets.only(bottom: 18),
                child: topTab == 2
                    ? FinishedMatchCard(match: item, onTap: widget.onOpenMatch)
                    : UpcomingMatchCard(match: item, onTap: widget.onOpenMatch, onReminder: widget.onOpenReminders),
              ),
          ],
        ),
      ),
    );
  }
}
