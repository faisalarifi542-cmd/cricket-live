import 'package:flutter/material.dart';

import '../app_theme.dart';
import '../components.dart';
import '../models.dart';

class SeriesHeroCard extends StatelessWidget {
  const SeriesHeroCard({super.key});

  @override
  Widget build(BuildContext context) {
    final c = context.cric;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(26), border: Border.all(color: c.border)),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/images/stadium_live.png',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const EmptyOrErrorImage(label: 'Series hero'),
            ),
          ),
          Positioned.fill(child: DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.black.withValues(alpha: .20), Colors.black.withValues(alpha: .74)])))),
          Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TeamBadge(AppData.india, size: 116),
                  Expanded(
                    child: Column(
                      children: [
                        Text('INTERNATIONAL TOUR', style: TextStyle(color: c.cyan, fontWeight: FontWeight.w800, fontSize: context.sp(15))),
                        const SizedBox(height: 10),
                        Text('India Tour of Australia\n2024-25', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: context.sp(28), height: 1.15)),
                        const SizedBox(height: 12),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.calendar_month_rounded, color: Colors.white.withValues(alpha: .82)),
                            const SizedBox(width: 10),
                            Text('22 Nov 2024 – 7 Jan 2025', style: TextStyle(color: c.cyan, fontWeight: FontWeight.w700, fontSize: context.sp(17))),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Text('3 Test  •  3 ODI  •  5 T20I', style: TextStyle(color: Colors.white.withValues(alpha: .86), fontSize: context.sp(18), fontWeight: FontWeight.w600)),
                      ],
                    ),
                  ),
                  TeamBadge(AppData.australia, size: 116),
                ],
              )
            ],
          )
        ],
      ),
    );
  }
}

class SeriesOverviewTab extends StatelessWidget {
  const SeriesOverviewTab({super.key, required this.onOpenReminder});

  final VoidCallback onOpenReminder;

  @override
  Widget build(BuildContext context) {
    final c = context.cric;
    return Column(
      children: [
        PremiumCard(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('SERIES INFO', style: TextStyle(color: c.cyan, fontWeight: FontWeight.w800, fontSize: 18)),
              const SizedBox(height: 16),
              Wrap(
                runSpacing: 18,
                spacing: 18,
                children: AppData.seriesOverviewStats
                    .map(
                      (e) => SizedBox(
                        width: context.w > 600 ? 240 : (context.w - context.horizontalPadding * 2 - 18) / 2,
                        child: Row(
                          children: [
                            CircleAvatar(radius: 24, backgroundColor: c.card2, child: Icon(e.icon, color: c.muted)),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(e.label, style: TextStyle(color: c.muted, fontSize: 14)),
                                  const SizedBox(height: 4),
                                  Text(e.value, style: TextStyle(color: e.label == 'Series Status' ? c.success : c.text, fontWeight: FontWeight.w700, fontSize: 16.5)),
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    )
                    .toList(),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        PremiumCard(
          padding: const EdgeInsets.all(20),
          child: Row(
            children: [
              Expanded(
                child: Row(
                  children: [
                    TeamBadge(AppData.india, size: 64),
                    const SizedBox(width: 10),
                    Text('VS', style: TextStyle(color: c.text, fontWeight: FontWeight.w900)),
                    const SizedBox(width: 10),
                    TeamBadge(AppData.australia, size: 64),
                  ],
                ),
              ),
              Container(width: 1, height: 120, color: c.border),
              const SizedBox(width: 18),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('NEXT MATCH', style: TextStyle(color: c.cyan, fontWeight: FontWeight.w800, fontSize: 18)),
                    const SizedBox(height: 12),
                    Text('22 – 26 Nov 2024', style: TextStyle(color: c.text, fontWeight: FontWeight.w700, fontSize: 16)),
                    const SizedBox(height: 8),
                    Text('Optus Stadium\nPerth', style: TextStyle(color: c.muted, fontSize: 15, height: 1.5)),
                    const SizedBox(height: 8),
                    Text('Starts 9:30 AM (Local)', style: TextStyle(color: c.text, fontSize: 15)),
                    const SizedBox(height: 14),
                    SizedBox(width: 220, child: GradientButton(label: 'Set Reminder', icon: Icons.notifications_none_rounded, onTap: onOpenReminder, height: 50)),
                  ],
                ),
              )
            ],
          ),
        ),
        const SizedBox(height: 16),
        PremiumCard(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('VENUES', style: TextStyle(color: c.cyan, fontWeight: FontWeight.w800, fontSize: 18)),
              const SizedBox(height: 14),
              SizedBox(
                height: 150,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (_, i) {
                    final venues = [
                      ('Perth Stadium', 'Perth'),
                      ('Adelaide Oval', 'Adelaide'),
                      ('The Gabba', 'Brisbane'),
                      ('MCG', 'Melbourne'),
                      ('SCG', 'Sydney'),
                    ];
                    final venue = venues[i];
                    return PremiumCard(
                      padding: const EdgeInsets.all(8),
                      radius: 18,
                      child: SizedBox(
                        width: 150,
                        child: Column(
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(14),
                              child: SizedBox(
                                height: 84,
                                width: double.infinity,
                                child: Image.asset('assets/images/stadium_live.png', fit: BoxFit.cover, errorBuilder: (_, __, ___) => const EmptyOrErrorImage(label: 'Venue')),
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(venue.$1, textAlign: TextAlign.center, style: TextStyle(color: c.text, fontWeight: FontWeight.w700)),
                            Text(venue.$2, textAlign: TextAlign.center, style: TextStyle(color: c.muted)),
                          ],
                        ),
                      ),
                    );
                  },
                  separatorBuilder: (_, __) => const SizedBox(width: 12),
                  itemCount: 5,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 3,
              child: PremiumCard(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('SERIES FORM / MOMENTUM', style: TextStyle(color: c.cyan, fontWeight: FontWeight.w800, fontSize: 18)),
                    const SizedBox(height: 16),
                    _formRow(context, AppData.india, ['W', 'W', 'W', '-', '-'], 'Won Last 3'),
                    const SizedBox(height: 14),
                    _formRow(context, AppData.australia, ['L', 'W', 'L', '-', '-'], 'Mixed Form'),
                    const SizedBox(height: 18),
                    Row(
                      children: [
                        Expanded(child: _radialStatCard(context, 'Completed', '2', 'Matches')),
                        const SizedBox(width: 12),
                        Expanded(child: _radialStatCard(context, 'Upcoming', '9', 'Matches', accent: const Color(0xff5b8cff))),
                      ],
                    )
                  ],
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              flex: 2,
              child: PremiumCard(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('SERIES INSIGHT', style: TextStyle(color: c.cyan, fontWeight: FontWeight.w800, fontSize: 18)),
                    const SizedBox(height: 12),
                    const Center(child: Icon(Icons.emoji_events_rounded, color: Color(0xffffc83d), size: 96)),
                    const SizedBox(height: 12),
                    Text('Trophy at Stake', style: TextStyle(color: c.text, fontWeight: FontWeight.w800, fontSize: 19)),
                    const SizedBox(height: 8),
                    Text('Custom Border-Gavaskar Trophy', style: TextStyle(color: c.muted, height: 1.5)),
                  ],
                ),
              ),
            )
          ],
        )
      ],
    );
  }

  Widget _formRow(BuildContext context, TeamInfo team, List<String> form, String label) {
    final c = context.cric;
    return Row(
      children: [
        TeamBadge(team, size: 28),
        const SizedBox(width: 10),
        SizedBox(width: 90, child: Text(team.name, style: TextStyle(color: c.text, fontWeight: FontWeight.w700))),
        const SizedBox(width: 8),
        for (final item in form)
          Container(
            margin: const EdgeInsets.only(right: 8),
            width: 28,
            height: 28,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: item == 'W'
                  ? c.success.withValues(alpha: .22)
                  : item == 'L'
                      ? c.live.withValues(alpha: .22)
                      : c.card2,
            ),
            alignment: Alignment.center,
            child: Text(item, style: TextStyle(color: item == 'W' ? c.success : item == 'L' ? c.live : c.muted, fontWeight: FontWeight.w900)),
          ),
        const Spacer(),
        Text(label, style: TextStyle(color: label == 'Won Last 3' ? c.success : c.warning, fontWeight: FontWeight.w700)),
      ],
    );
  }

  Widget _radialStatCard(BuildContext context, String title, String value, String subtitle, {Color? accent}) {
    final c = context.cric;
    final a = accent ?? c.cyan;
    return PremiumCard(
      padding: const EdgeInsets.all(16),
      radius: 18,
      child: Row(
        children: [
          SizedBox(
            width: 72,
            height: 72,
            child: Stack(
              alignment: Alignment.center,
              children: [
                CircularProgressIndicator(value: .72, strokeWidth: 8, valueColor: AlwaysStoppedAnimation<Color>(a), backgroundColor: c.card2),
                Text(value, style: TextStyle(color: c.text, fontWeight: FontWeight.w900, fontSize: 22)),
              ],
            ),
          ),
          const SizedBox(width: 14),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: TextStyle(color: c.muted)),
              const SizedBox(height: 6),
              Text(subtitle, style: TextStyle(color: c.text, fontWeight: FontWeight.w700)),
            ],
          )
        ],
      ),
    );
  }
}

class SeriesMatchesTab extends StatelessWidget {
  const SeriesMatchesTab({super.key, required this.onOpenCalendar});

  final VoidCallback onOpenCalendar;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Align(alignment: Alignment.centerLeft, child: Padding(padding: EdgeInsets.only(bottom: 10), child: Text('UPCOMING MATCHES', style: TextStyle(color: Color(0xff00d9ff), fontWeight: FontWeight.w800, fontSize: 18)))),
        for (final row in AppData.seriesUpcomingRows)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: SeriesMatchRowCard(row: row),
          ),
        const SizedBox(height: 8),
        const Align(alignment: Alignment.centerLeft, child: Padding(padding: EdgeInsets.only(bottom: 10), child: Text('COMPLETED MATCHES', style: TextStyle(color: Color(0xff00d9ff), fontWeight: FontWeight.w800, fontSize: 18)))),
        for (final row in AppData.seriesCompletedRows)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: SeriesMatchRowCard(row: row, completed: true),
          ),
        const SizedBox(height: 14),
        GradientButton(label: 'Add Series to Calendar', icon: Icons.event_available_rounded, outlined: true, onTap: onOpenCalendar),
      ],
    );
  }
}

class SeriesSquadsTab extends StatelessWidget {
  const SeriesSquadsTab({
    super.key,
    required this.squadTeam,
    required this.onTeamChanged,
    required this.onOpenPlayer,
  });

  final int squadTeam;
  final ValueChanged<int> onTeamChanged;
  final VoidCallback onOpenPlayer;

  @override
  Widget build(BuildContext context) {
    final c = context.cric;
    final top = AppData.indiaSquadTop;
    final middle = AppData.indiaSquadMiddle;
    final allRounders = AppData.indiaAllRounders;
    final bowlers = AppData.indiaBowlers;
    final reserves = AppData.indiaReserves;
    return Column(
      children: [
        SegmentedTabs(
          items: const [('India', null), ('Australia', null)],
          selected: squadTeam,
          onChanged: onTeamChanged,
          height: 56,
        ),
        const SizedBox(height: 18),
        _squadSection(context, 'TOP ORDER', top, columns: 5, onTap: onOpenPlayer),
        const SizedBox(height: 16),
        _squadSection(context, 'MIDDLE ORDER', middle, columns: 4, onTap: onOpenPlayer),
        const SizedBox(height: 16),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(flex: 3, child: _squadSection(context, 'ALL-ROUNDERS', allRounders, columns: 3, onTap: onOpenPlayer)),
            const SizedBox(width: 16),
            Expanded(
              flex: 2,
              child: PremiumCard(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('BOWLERS', style: TextStyle(color: c.cyan, fontWeight: FontWeight.w800, fontSize: 18)),
                    const SizedBox(height: 12),
                    for (final bowler in bowlers)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: Row(
                          children: [
                            PlayerAvatar(player: bowler, size: 42),
                            const SizedBox(width: 10),
                            Expanded(child: Text(bowler.name, style: TextStyle(color: c.text, fontWeight: FontWeight.w700))),
                            StatusBadge(label: 'BOWL', color: const Color(0xff8b5cff), filled: true),
                          ],
                        ),
                      )
                  ],
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        PremiumCard(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('RESERVE PLAYERS', style: TextStyle(color: c.cyan, fontWeight: FontWeight.w800, fontSize: 18)),
              const SizedBox(height: 12),
              Row(
                children: reserves
                    .map((p) => Expanded(
                          child: Padding(
                            padding: EdgeInsets.only(right: p == reserves.last ? 0 : 10),
                            child: ReservePlayerChip(player: p),
                          ),
                        ))
                    .toList(),
              )
            ],
          ),
        ),
        const SizedBox(height: 18),
        Row(
          children: const [
            Expanded(child: GradientButton(label: 'Compare Teams', icon: Icons.groups_rounded, outlined: true)),
            SizedBox(width: 12),
            Expanded(child: GradientButton(label: 'View Full Squad', icon: Icons.arrow_forward_rounded)),
          ],
        )
      ],
    );
  }

  Widget _squadSection(BuildContext context, String title, List<PlayerInfo> players, {required int columns, required VoidCallback onTap}) {
    final c = context.cric;
    return PremiumCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: TextStyle(color: c.cyan, fontWeight: FontWeight.w800, fontSize: 18)),
          const SizedBox(height: 12),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: players
                .map(
                  (player) => SizedBox(
                    width: columns == 5
                        ? (context.w - context.horizontalPadding * 2 - 16 * 2 - 12 * 4) / 5
                        : columns == 4
                            ? (context.w - context.horizontalPadding * 2 - 16 * 2 - 12 * 3) / 4
                            : 150,
                    child: SquadPlayerCard(player: player, onTap: onTap),
                  ),
                )
                .toList(),
          )
        ],
      ),
    );
  }
}

class SeriesStatsTab extends StatelessWidget {
  const SeriesStatsTab({super.key});

  @override
  Widget build(BuildContext context) {
    final c = context.cric;
    return Column(
      children: [
        PremiumCard(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('POINTS TABLE (TEST SERIES)', style: TextStyle(color: c.cyan, fontWeight: FontWeight.w800, fontSize: 18)),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(color: c.card2, borderRadius: BorderRadius.circular(14), border: Border.all(color: c.border)),
                child: Row(
                  children: const [
                    Expanded(flex: 1, child: Text('#')),
                    Expanded(flex: 3, child: Text('TEAM')),
                    Expanded(child: Text('P')),
                    Expanded(child: Text('W')),
                    Expanded(child: Text('L')),
                    Expanded(child: Text('D')),
                    Expanded(child: Text('PTS')),
                    Expanded(child: Text('PCT')),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              _pointsRow(context, '1', AppData.india, ['3', '2', '1', '0', '16', '66.67']),
              const Divider(color: Color(0xff1b4266)),
              _pointsRow(context, '2', AppData.australia, ['3', '1', '2', '0', '8', '33.33']),
              const SizedBox(height: 12),
              Row(
                children: [
                  Icon(Icons.info_outline_rounded, color: c.muted),
                  const SizedBox(width: 8),
                  Text('India won the Test series 2-1', style: TextStyle(color: c.text, fontWeight: FontWeight.w700)),
                ],
              )
            ],
          ),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(child: _leaderCard(context, 'TOP RUN SCORERS', AppData.topRunScorers)),
            const SizedBox(width: 16),
            Expanded(child: _leaderCard(context, 'TOP WICKET TAKERS', AppData.topWickets)),
          ],
        ),
        const SizedBox(height: 16),
        PremiumCard(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('SERIES STATS', style: TextStyle(color: c.cyan, fontWeight: FontWeight.w800, fontSize: 18)),
              const SizedBox(height: 18),
              Wrap(
                runSpacing: 20,
                spacing: 20,
                children: const [
                  StatTile(icon: Icons.sports_cricket_rounded, title: 'Most Runs', value: '766', subtitle: 'Total Runs'),
                  StatTile(icon: Icons.sports_baseball_rounded, title: 'Most Wickets', value: '58', subtitle: 'Total Wickets'),
                  StatTile(icon: Icons.calendar_month_rounded, title: 'Matches Played', value: '11', subtitle: '3 Tests • 3 ODIs • 5 T20Is'),
                  StatTile(icon: Icons.stadium_outlined, title: 'Venues', value: '5', subtitle: 'Perth, Adelaide, MCG +2'),
                  StatTile(icon: Icons.emoji_events_outlined, title: 'Player of Series', value: 'Jasprit Bumrah', subtitle: '(IND)'),
                  StatTile(icon: Icons.star_outline_rounded, title: 'Series Result', value: 'India won', subtitle: '2-1 (Test) | 2-1 (ODI)'),
                ],
              )
            ],
          ),
        )
      ],
    );
  }

  Widget _pointsRow(BuildContext context, String rank, TeamInfo team, List<String> stats) {
    final c = context.cric;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          Expanded(flex: 1, child: Text(rank, style: TextStyle(color: c.text, fontWeight: FontWeight.w700))),
          Expanded(
            flex: 3,
            child: Row(children: [TeamBadge(team, size: 34), const SizedBox(width: 10), Expanded(child: Text(team.name, style: TextStyle(color: c.text, fontWeight: FontWeight.w700)))]),
          ),
          for (final item in stats) Expanded(child: Text(item, style: TextStyle(color: c.text, fontWeight: FontWeight.w600))),
        ],
      ),
    );
  }

  Widget _leaderCard(BuildContext context, String title, List<PlayerInfo> players) {
    final c = context.cric;
    return PremiumCard(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: TextStyle(color: c.cyan, fontWeight: FontWeight.w800, fontSize: 18)),
          const SizedBox(height: 14),
          for (final player in players) ...[
            Row(
              children: [
                PlayerAvatar(player: player, size: 46),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(player.name, style: TextStyle(color: c.text, fontWeight: FontWeight.w700)),
                      Text(player.team.code, style: TextStyle(color: c.muted)),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(player.stat ?? '', style: TextStyle(color: c.text, fontWeight: FontWeight.w900, fontSize: 28)),
                    Text(player.secondaryStat ?? '', style: TextStyle(color: c.muted)),
                  ],
                )
              ],
            ),
            if (player != players.last) const Divider(color: Color(0xff1b4266)),
          ],
          const SizedBox(height: 14),
          const GradientButton(label: 'View Full List', icon: Icons.arrow_forward_rounded, outlined: true, height: 48),
        ],
      ),
    );
  }
}

class SeriesMatchRowCard extends StatelessWidget {
  const SeriesMatchRowCard({super.key, required this.row, this.completed = false});

  final SeriesMatchRow row;
  final bool completed;

  @override
  Widget build(BuildContext context) {
    final c = context.cric;
    return PremiumCard(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(row.label, style: TextStyle(color: c.cyan, fontWeight: FontWeight.w800, fontSize: 16)),
                const SizedBox(height: 10),
                Row(
                  children: [
                    TeamBadge(row.left, size: 40),
                    const SizedBox(width: 10),
                    Text('VS', style: TextStyle(color: c.text, fontWeight: FontWeight.w900)),
                    const SizedBox(width: 10),
                    TeamBadge(row.right, size: 40),
                  ],
                ),
                const SizedBox(height: 10),
                Text('${row.left.code} vs ${row.right.code}', style: TextStyle(color: c.text, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
          Expanded(
            flex: 3,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(row.date, style: TextStyle(color: c.text, fontWeight: FontWeight.w700, fontSize: 16)),
                const SizedBox(height: 10),
                Text(row.venue, style: TextStyle(color: c.muted, height: 1.45)),
              ],
            ),
          ),
          Expanded(
            flex: 2,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                StatusBadge(label: row.status, color: completed ? (row.status.contains('IND') ? c.success : const Color(0xff5ce1ff)) : c.cyan, filled: true),
                const SizedBox(height: 12),
                Text(row.trailing, textAlign: TextAlign.right, style: TextStyle(color: completed ? c.success : c.text, fontWeight: FontWeight.w700, fontSize: 16, height: 1.45)),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Icon(Icons.chevron_right_rounded, color: c.muted),
        ],
      ),
    );
  }
}

class SquadPlayerCard extends StatelessWidget {
  const SquadPlayerCard({super.key, required this.player, this.onTap});

  final PlayerInfo player;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final c = context.cric;
    final badgeColor = switch (player.role) {
      'BAT' => c.cyan,
      'WK' => const Color(0xff3b82f6),
      'AR' => const Color(0xff14b8a6),
      _ => const Color(0xff8b5cff),
    };
    return PremiumCard(
      onTap: onTap,
      padding: const EdgeInsets.all(12),
      radius: 18,
      child: Column(
        children: [
          Row(
            children: [
              if (player.order != null)
                Container(
                  width: 28,
                  height: 28,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: c.card2, border: Border.all(color: c.cyan.withValues(alpha: .6))),
                  alignment: Alignment.center,
                  child: Text('${player.order}', style: TextStyle(color: c.cyan, fontWeight: FontWeight.w900)),
                ),
              const Spacer(),
              StatusBadge(label: player.role, color: badgeColor, filled: true),
            ],
          ),
          const SizedBox(height: 8),
          PlayerAvatar(player: player, size: 86, borderColor: Colors.white.withValues(alpha: .26)),
          const SizedBox(height: 12),
          Text(player.name, textAlign: TextAlign.center, style: TextStyle(color: c.text, fontWeight: FontWeight.w800, fontSize: 18, height: 1.15)),
          if (player.subtitle != null) ...[
            const SizedBox(height: 6),
            Text(player.subtitle!, textAlign: TextAlign.center, style: TextStyle(color: c.cyan, fontWeight: FontWeight.w700, height: 1.3)),
          ]
        ],
      ),
    );
  }
}

class ReservePlayerChip extends StatelessWidget {
  const ReservePlayerChip({super.key, required this.player});

  final PlayerInfo player;

  @override
  Widget build(BuildContext context) {
    final c = context.cric;
    return PremiumCard(
      padding: const EdgeInsets.all(10),
      radius: 16,
      child: Column(
        children: [
          Row(
            children: [
              PlayerAvatar(player: player, size: 40),
              const SizedBox(width: 10),
              Expanded(child: Text(player.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: c.text, fontWeight: FontWeight.w700, height: 1.2))),
            ],
          ),
          const SizedBox(height: 8),
          Align(alignment: Alignment.centerLeft, child: StatusBadge(label: player.role, color: player.role == 'BOWL' ? const Color(0xff8b5cff) : player.role == 'AR' ? const Color(0xff14b8a6) : player.role == 'WK' ? const Color(0xff3b82f6) : c.cyan, filled: true)),
        ],
      ),
    );
  }
}

class StatTile extends StatelessWidget {
  const StatTile({super.key, required this.icon, required this.title, required this.value, required this.subtitle});

  final IconData icon;
  final String title;
  final String value;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    final c = context.cric;
    return SizedBox(
      width: context.w > 700 ? 240 : (context.w - context.horizontalPadding * 2 - 20) / 2,
      child: Row(
        children: [
          CircleAvatar(radius: 28, backgroundColor: c.card2, child: Icon(icon, color: c.muted)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: TextStyle(color: c.muted)),
                const SizedBox(height: 4),
                Text(value, style: TextStyle(color: c.text, fontWeight: FontWeight.w900, fontSize: 24)),
                Text(subtitle, style: TextStyle(color: c.muted, height: 1.35)),
              ],
            ),
          )
        ],
      ),
    );
  }
}



