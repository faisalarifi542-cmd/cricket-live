import 'package:flutter/material.dart';

import '../app_theme.dart';
import '../components.dart';
import '../models.dart';
import 'series_components.dart';

class MatchDetailHeroCard extends StatelessWidget {
  const MatchDetailHeroCard({super.key, this.onWatchLive});

  final VoidCallback? onWatchLive;

  @override
  Widget build(BuildContext context) {
    final c = context.cric;
    final w = context.w;
    final narrow = w <= 400;
    final pad = narrow ? 14.0 : 16.0;
    final badge = narrow ? 56.0 : 78.0;
    return Container(
      padding: EdgeInsets.all(pad),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), border: Border.all(color: c.border)),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        children: [
          Positioned.fill(
            child: Image.asset('assets/images/stadium_live.png', fit: BoxFit.cover, errorBuilder: (_, __, ___) => const EmptyOrErrorImage(label: 'Match')),
          ),
          Positioned.fill(child: DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.black.withValues(alpha: .18), Colors.black.withValues(alpha: .76)])))),
          Column(
            children: [
              Row(
                children: [
                  StatusBadge(label: 'LIVE', color: c.live, filled: true),
                  const SizedBox(width: 10),
                  Expanded(child: Text('1st Test • Day 1', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white.withValues(alpha: .92), fontWeight: FontWeight.w700))),
                  const SizedBox(width: 8),
                  StatusBadge(label: '128K', color: Colors.white, filled: true),
                ],
              ),
              const SizedBox(height: 12),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'West Indies Tour of New Zealand, 2025',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: Colors.white.withValues(alpha: .92), fontWeight: FontWeight.w700, fontSize: context.sp(15)),
                ),
              ),
              SizedBox(height: narrow ? 16 : 22),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Expanded(child: _compactTeam(context, AppData.newZealand, badge)),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text('VS', style: TextStyle(color: Colors.white.withValues(alpha: .88), fontWeight: FontWeight.w800)),
                      const SizedBox(height: 8),
                      FittedBox(
                        fit: BoxFit.scaleDown,
                        child: Text('158/3', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: context.sp(narrow ? 34 : 44), height: .95)),
                      ),
                      const SizedBox(height: 4),
                      Text('(38.4 OV)', style: TextStyle(color: Colors.white.withValues(alpha: .88), fontWeight: FontWeight.w700, fontSize: context.sp(13))),
                    ],
                  ),
                  Expanded(child: _compactTeam(context, AppData.westIndies, badge)),
                ],
              ),
              SizedBox(height: narrow ? 14 : 20),
              Text('NZ won the toss & chose to bat', textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: c.cyan, fontWeight: FontWeight.w700, fontSize: context.sp(13))),
              const SizedBox(height: 16),
              ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 240),
                child: GradientButton(
                  label: 'Watch Live',
                  icon: Icons.play_circle_fill_rounded,
                  height: 50,
                  onTap: onWatchLive,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _compactTeam(BuildContext context, TeamInfo team, double badge) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        TeamBadge(team, size: badge),
        const SizedBox(height: 10),
        Text(
          team.shortName.toUpperCase(),
          textAlign: TextAlign.center,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: context.sp(13)),
        ),
      ],
    );
  }
}

class MatchScorecardTab extends StatelessWidget {
  const MatchScorecardTab({super.key});

  @override
  Widget build(BuildContext context) {
    final c = context.cric;
    final batting = [
      ('K Williamson', '64*', '78', '6', '1', '82.05'),
      ('R Ravindra', '22*', '29', '3', '0', '75.86'),
      ('D Conway', '28', '42', '4', '0', '66.67'),
      ('T Latham (wk)', '16', '24', '1', '0', '66.67'),
      ('G Phillips', '8', '10', '0', '1', '80.00'),
    ];
    return PremiumCard(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text('NZ 158/3  (38.4 OV)', style: TextStyle(color: c.text, fontWeight: FontWeight.w900, fontSize: 18)),
              const SizedBox(width: 10),
              StatusBadge(label: '1st Innings', color: c.primary, filled: true),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(color: c.card2, borderRadius: BorderRadius.circular(14)),
            child: Row(
              children: const [
                Expanded(flex: 4, child: Text('Batting')),
                Expanded(child: Text('R')),
                Expanded(child: Text('B')),
                Expanded(child: Text('4s')),
                Expanded(child: Text('6s')),
                Expanded(child: Text('SR')),
              ],
            ),
          ),
          const SizedBox(height: 10),
          for (final row in batting) ...[
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 9),
              child: Row(
                children: [
                  Expanded(flex: 4, child: Text(row.$1, style: TextStyle(color: c.text, fontWeight: FontWeight.w700))),
                  Expanded(child: Text(row.$2, style: TextStyle(color: c.text))),
                  Expanded(child: Text(row.$3, style: TextStyle(color: c.text))),
                  Expanded(child: Text(row.$4, style: TextStyle(color: c.text))),
                  Expanded(child: Text(row.$5, style: TextStyle(color: c.text))),
                  Expanded(child: Text(row.$6, style: TextStyle(color: c.text))),
                ],
              ),
            ),
            if (row != batting.last) const Divider(color: Color(0xff1b4266)),
          ],
          const Divider(color: Color(0xff1b4266)),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: Row(
              children: [
                Expanded(flex: 4, child: Text('Extras', style: TextStyle(color: c.text, fontWeight: FontWeight.w700))),
                Expanded(flex: 2, child: Text('(b 1, lb 2, w 3, nb 0)', style: TextStyle(color: c.muted))),
                Expanded(child: Text('6', style: TextStyle(color: c.text, fontWeight: FontWeight.w800))),
              ],
            ),
          ),
          const Divider(color: Color(0xff1b4266)),
          Row(
            children: [
              Expanded(child: Text('Total', style: TextStyle(color: c.cyan, fontWeight: FontWeight.w800, fontSize: 17))),
              Text('158/3 (38.4 OV)', style: TextStyle(color: c.cyan, fontWeight: FontWeight.w900, fontSize: 17)),
            ],
          ),
        ],
      ),
    );
  }
}

class MatchCommentaryTab extends StatelessWidget {
  const MatchCommentaryTab({super.key});

  @override
  Widget build(BuildContext context) {
    final items = [
      ('38.4', '2 runs', 'Mitchell clips Holder through midwicket to bring up another productive over.', false),
      ('37.5', 'WICKET', 'Williamson falls attempting the late cut. Holder gets the breakthrough.', true),
      ('36.2', 'FOUR', 'Conway drives gloriously on the up through cover.', false),
      ('35.6', 'SIX', 'Phillips launches the final ball over long-on.', false),
    ];
    return Column(
      children: [
        const PremiumCard(
          padding: EdgeInsets.all(18),
          child: Row(
            children: [
              Expanded(child: _MiniCommentaryStat(title: 'Runs', value: '158')),
              Expanded(child: _MiniCommentaryStat(title: 'Wickets', value: '3')),
              Expanded(child: _MiniCommentaryStat(title: 'Run Rate', value: '4.12')),
            ],
          ),
        ),
        const SizedBox(height: 14),
        for (final item in items)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: PremiumCard(
              padding: const EdgeInsets.all(16),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    children: [
                      CircleAvatar(radius: 20, backgroundColor: item.$4 ? const Color(0xffff2d45) : const Color(0xff0a2748), child: Text(item.$1, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 12))),
                      Container(width: 2, height: 50, color: const Color(0xff1b4266)),
                    ],
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            StatusBadge(label: item.$2, color: item.$2 == 'WICKET' ? const Color(0xffff2d45) : item.$2 == 'FOUR' ? const Color(0xff00d9ff) : const Color(0xff38f28b), filled: true),
                            const SizedBox(width: 10),
                            const Text('NZ 158/3', style: TextStyle(fontWeight: FontWeight.w700)),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Text(item.$3, style: TextStyle(color: context.cric.text, fontSize: 16, height: 1.55)),
                      ],
                    ),
                  )
                ],
              ),
            ),
          )
      ],
    );
  }
}

class _MiniCommentaryStat extends StatelessWidget {
  const _MiniCommentaryStat({required this.title, required this.value});

  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(title, style: TextStyle(color: context.cric.muted)),
        const SizedBox(height: 6),
        Text(value, style: TextStyle(color: context.cric.text, fontWeight: FontWeight.w900, fontSize: 22)),
      ],
    );
  }
}

class MatchOversTab extends StatelessWidget {
  const MatchOversTab({super.key});

  @override
  Widget build(BuildContext context) {
    final c = context.cric;
    final w = context.w;
    final narrow = w <= 400;
    final cardPad = narrow ? 12.0 : 16.0;
    final chartHeight = narrow ? 160.0 : (w <= 480 ? 190.0 : 220.0);
    final overs = [
      ('38', '8', 'Alzarri Joseph', 'Fast', ['1', '0', '4', '0', '1', '2'], 'Daryl Mitchell 64 (83)', 'Tom Latham 27 (38)'),
      ('37', '9', 'Jason Holder', 'Medium Fast', ['0', '4', '1', 'W', '2', '2'], 'Daryl Mitchell 60 (79)', 'Tom Latham 26 (36)'),
      ('36', '8', 'Alzarri Joseph', 'Fast', ['1', '1', '0', '4', '1', '1'], 'Daryl Mitchell 55 (74)', 'Tom Latham 25 (34)'),
      ('35', '11', 'Jason Holder', 'Medium Fast', ['4', '0', '4', '1', '1', '1'], 'Daryl Mitchell 54 (71)', 'Tom Latham 24 (33)'),
    ];
    return Column(
      children: [
        PremiumCard(
          padding: EdgeInsets.all(cardPad),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(child: Text('Run Progression', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: c.text, fontWeight: FontWeight.w900, fontSize: context.sp(17)))),
                  Container(
                    width: 28,
                    height: 28,
                    decoration: BoxDecoration(color: c.card2, borderRadius: BorderRadius.circular(8), border: Border.all(color: c.border)),
                    child: Icon(Icons.open_in_full_rounded, color: c.muted, size: 16),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 12,
                runSpacing: 6,
                children: [
                  _legendDot(context, c.cyan, 'New Zealand'),
                  _legendDot(context, c.live, 'West Indies'),
                ],
              ),
              const SizedBox(height: 14),
              LayoutBuilder(
                builder: (ctx, constraints) {
                  return SizedBox(
                    width: constraints.maxWidth,
                    height: chartHeight,
                    child: CustomPaint(
                      size: Size(constraints.maxWidth, chartHeight),
                      painter: _RunChartPainter(c, compact: narrow),
                    ),
                  );
                },
              ),
              const SizedBox(height: 12),
              Divider(color: c.border, height: 1),
              const SizedBox(height: 12),
              Text('Recent Overs', style: TextStyle(color: c.text, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              Text.rich(TextSpan(style: TextStyle(color: c.muted, fontSize: 12.5), children: [
                const TextSpan(text: 'Runs: '),
                TextSpan(text: '42', style: TextStyle(color: c.cyan, fontWeight: FontWeight.w900)),
                const TextSpan(text: '   Wickets: '),
                TextSpan(text: '1', style: TextStyle(color: c.cyan, fontWeight: FontWeight.w900)),
                const TextSpan(text: '   Avg: '),
                TextSpan(text: '7.00', style: TextStyle(color: c.cyan, fontWeight: FontWeight.w900)),
              ])),
              const SizedBox(height: 12),
              SizedBox(
                height: 60,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    for (final item in [('34', '6'), ('35', '11'), ('36', '8'), ('37', '9'), ('38', '8*')])
                      Padding(
                        padding: const EdgeInsets.only(right: 10),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(item.$1, style: TextStyle(color: c.muted, fontSize: 12, fontWeight: FontWeight.w700)),
                            const SizedBox(height: 4),
                            _BallChip(label: item.$2, highlight: item.$2 == '11' || item.$2 == '8*', wicket: item.$2 == '9'),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        for (final over in overs)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: _OverRow(
              overNumber: over.$1,
              overRuns: over.$2,
              bowler: over.$3,
              bowlerType: over.$4,
              balls: over.$5,
              batter1: over.$6,
              batter2: over.$7,
              narrow: narrow,
            ),
          )
      ],
    );
  }

  Widget _legendDot(BuildContext context, Color color, String label) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        CircleAvatar(radius: 4, backgroundColor: color),
        const SizedBox(width: 5),
        Text(label, style: TextStyle(color: context.cric.muted, fontSize: 12)),
      ],
    );
  }
}

class _OverRow extends StatelessWidget {
  const _OverRow({
    required this.overNumber,
    required this.overRuns,
    required this.bowler,
    required this.bowlerType,
    required this.balls,
    required this.batter1,
    required this.batter2,
    required this.narrow,
  });

  final String overNumber;
  final String overRuns;
  final String bowler;
  final String bowlerType;
  final List<String> balls;
  final String batter1;
  final String batter2;
  final bool narrow;

  @override
  Widget build(BuildContext context) {
    final c = context.cric;
    if (narrow) {
      return PremiumCard(
        padding: const EdgeInsets.all(12),
        radius: 18,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                _overBlock(context, c),
                const SizedBox(width: 12),
                Expanded(child: _bowlerBlock(context, c)),
                Icon(Icons.chevron_right_rounded, color: c.muted),
              ],
            ),
            const SizedBox(height: 10),
            Wrap(spacing: 6, runSpacing: 6, children: [
              for (final ball in balls) _BallChip(label: ball, highlight: ball == '4' || ball == '6', wicket: ball == 'W'),
            ]),
            const SizedBox(height: 10),
            Container(height: 1, color: c.border),
            const SizedBox(height: 10),
            _batterRow(context, c, batter1),
            const SizedBox(height: 4),
            _batterRow(context, c, batter2),
          ],
        ),
      );
    }
    return PremiumCard(
      padding: const EdgeInsets.all(14),
      radius: 18,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          _overBlock(context, c),
          VerticalDivider(color: c.border, width: 22),
          Expanded(
            flex: 5,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _bowlerBlock(context, c),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 6,
                  children: [
                    for (final ball in balls) _BallChip(label: ball, highlight: ball == '4' || ball == '6', wicket: ball == 'W'),
                  ],
                ),
              ],
            ),
          ),
          VerticalDivider(color: c.border, width: 22),
          Expanded(
            flex: 4,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _batterRow(context, c, batter1),
                const SizedBox(height: 6),
                _batterRow(context, c, batter2),
              ],
            ),
          ),
          Icon(Icons.chevron_right_rounded, color: c.muted),
        ],
      ),
    );
  }

  Widget _overBlock(BuildContext context, CricColors c) {
    return SizedBox(
      width: 54,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('OVER', style: TextStyle(color: c.muted, fontSize: 10)),
          Text(overNumber, style: TextStyle(color: c.cyan, fontWeight: FontWeight.w900, fontSize: 28)),
          Text('$overRuns RUNS', style: TextStyle(color: c.cyan, fontSize: 10, fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }

  Widget _bowlerBlock(BuildContext context, CricColors c) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(children: [
          Container(width: 8, height: 8, decoration: BoxDecoration(color: c.live, shape: BoxShape.circle)),
          const SizedBox(width: 6),
          Expanded(child: Text(bowler, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: c.text, fontWeight: FontWeight.w800))),
        ]),
        Padding(padding: const EdgeInsets.only(left: 14, top: 2), child: Text(bowlerType, style: TextStyle(color: c.muted, fontSize: 12))),
      ],
    );
  }

  Widget _batterRow(BuildContext context, CricColors c, String name) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(Icons.sports_cricket_rounded, color: c.cyan, size: 14),
        const SizedBox(width: 6),
        Expanded(child: Text(name, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: c.text, fontSize: 12, fontWeight: FontWeight.w700))),
      ],
    );
  }
}

class _RunChartPainter extends CustomPainter {
  _RunChartPainter(this.c, {this.compact = false});

  final CricColors c;
  final bool compact;

  TextPainter _label(String t, {Color? color, double size = 10, FontWeight weight = FontWeight.w700}) {
    final tp = TextPainter(
      text: TextSpan(text: t, style: TextStyle(color: color ?? c.muted, fontSize: size, fontWeight: weight)),
      textDirection: TextDirection.ltr,
    )..layout();
    return tp;
  }

  @override
  void paint(Canvas canvas, Size size) {
    if (size.width <= 0 || size.height <= 0) return;
    final leftPad = compact ? 26.0 : 32.0;
    final rightPad = compact ? 30.0 : 44.0;
    const bottomPad = 20.0;
    final chartW = size.width - leftPad - rightPad;
    final chartH = size.height - bottomPad;
    if (chartW <= 0 || chartH <= 0) return;

    final grid = Paint()
      ..color = c.border.withValues(alpha: .55)
      ..strokeWidth = 1;
    for (var i = 0; i <= 4; i++) {
      final y = chartH * i / 4;
      canvas.drawLine(Offset(leftPad, y), Offset(leftPad + chartW, y), grid);
      final label = _label('${200 - i * 50}');
      label.paint(canvas, Offset(leftPad - label.width - 8, y - label.height / 2));
    }
    final xSteps = compact ? 3 : 5;
    final lastIndex = xSteps;
    for (var i = 0; i <= xSteps; i++) {
      final x = leftPad + chartW * i / xSteps;
      if (i == lastIndex) continue;
      final overNum = (i * 50 / xSteps).round();
      final label = _label('$overNum');
      label.paint(canvas, Offset(x - label.width / 2, chartH + 4));
    }
    final overs = _label('OVERS', weight: FontWeight.w900, size: compact ? 9 : 10);
    overs.paint(canvas, Offset(leftPad + chartW - overs.width + 2, chartH + 4));

    final nz = [0, 12, 25, 38, 44, 56, 68, 80, 94, 105, 118, 127, 139, 145, 158];
    final wi = [0, 6, 11, 20, 25, 31, 38, 45, 52, 60, 66, 72, 78];

    final nzPaint = Paint()..color = c.cyan..strokeWidth = 3..style = PaintingStyle.stroke;
    final wiPaint = Paint()..color = c.live..strokeWidth = 2.4..style = PaintingStyle.stroke;

    final pathNz = Path();
    final pathWi = Path();
    Offset lastPoint = Offset.zero;
    for (var i = 0; i < nz.length; i++) {
      final x = leftPad + chartW * (i / (nz.length - 1)) * (42 / 50);
      final y = chartH - (nz[i] / 200) * chartH;
      lastPoint = Offset(x, y);
      if (i == 0) {
        pathNz.moveTo(x, y);
      } else {
        pathNz.lineTo(x, y);
      }
    }
    for (var i = 0; i < wi.length; i++) {
      final x = leftPad + chartW * (i / (nz.length - 1)) * (42 / 50);
      final y = chartH - (wi[i] / 200) * chartH;
      if (i == 0) {
        pathWi.moveTo(x, y);
      } else {
        pathWi.lineTo(x, y);
      }
    }
    canvas.drawPath(pathNz, nzPaint);
    canvas.drawPath(pathWi, wiPaint);

    final glow = Paint()
      ..color = c.cyan.withValues(alpha: .35)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 7);
    canvas.drawCircle(lastPoint, 8, glow);
    canvas.drawCircle(lastPoint, 5, Paint()..color = c.cyan);
    final label = _label('158/3', color: c.cyan, size: compact ? 12 : 14, weight: FontWeight.w900);
    final fitsRight = lastPoint.dx + 8 + label.width <= size.width;
    final labelDx = fitsRight ? lastPoint.dx + 8 : lastPoint.dx - 8 - label.width;
    label.paint(canvas, Offset(labelDx, lastPoint.dy - label.height / 2));
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _BallChip extends StatelessWidget {
  const _BallChip({required this.label, this.highlight = false, this.wicket = false});

  final String label;
  final bool highlight;
  final bool wicket;

  @override
  Widget build(BuildContext context) {
    final c = context.cric;
    final bg = wicket ? c.live : highlight ? c.primary : c.card2;
    return Container(
      width: 32,
      height: 32,
      decoration: BoxDecoration(color: bg, shape: BoxShape.circle),
      alignment: Alignment.center,
      child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 13)),
    );
  }
}

class MatchInfoTab extends StatelessWidget {
  const MatchInfoTab({super.key});

  @override
  Widget build(BuildContext context) {
    final cards = [
      StatTile(icon: Icons.stadium_outlined, title: 'Venue', value: 'Hagley Oval', subtitle: 'Christchurch'),
      StatTile(icon: Icons.sports_cricket_rounded, title: 'Toss', value: 'New Zealand', subtitle: 'elected to bat'),
      StatTile(icon: Icons.person_outline_rounded, title: 'Umpires', value: 'Kettleborough', subtitle: 'Gough'),
      StatTile(icon: Icons.wb_cloudy_outlined, title: 'Weather', value: 'Cloudy', subtitle: '18°C • Humid'),
      StatTile(icon: Icons.live_tv_rounded, title: 'Streaming', value: 'CricPro Live', subtitle: 'English & Hindi feed'),
      StatTile(icon: Icons.shield_outlined, title: 'Series', value: '3rd ODI', subtitle: 'Of 3 matches'),
    ];
    return PremiumCard(
      padding: const EdgeInsets.all(18),
      child: Wrap(spacing: 20, runSpacing: 20, children: cards),
    );
  }
}

class MatchSquadsTab extends StatelessWidget {
  const MatchSquadsTab({super.key});

  @override
  Widget build(BuildContext context) {
    final c = context.cric;
    final players = [
      'Devon Conway',
      'Rachin Ravindra',
      'Kane Williamson',
      'Daryl Mitchell',
      'Tom Latham',
      'Glenn Phillips',
    ];
    return Column(
      children: [
        PremiumCard(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: const [
              Expanded(child: _MiniCommentaryStat(title: 'Toss', value: 'NZ')),
              Expanded(child: _MiniCommentaryStat(title: 'Venue', value: 'Hagley')),
              Expanded(child: _MiniCommentaryStat(title: 'Umpires', value: '2')),
              Expanded(child: _MiniCommentaryStat(title: 'Series', value: '3rd ODI')),
            ],
          ),
        ),
        const SizedBox(height: 14),
        SegmentedTabs(items: const [('New Zealand', null), ('West Indies', null)], selected: 0, onChanged: (_) {}, height: 56),
        const SizedBox(height: 16),
        PremiumCard(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [Text('PLAYING XI', style: TextStyle(color: c.cyan, fontWeight: FontWeight.w800, fontSize: 18)), const Spacer(), Text('CAPTAIN: Mitchell Santner', style: TextStyle(color: c.muted, fontWeight: FontWeight.w700))]),
              const SizedBox(height: 12),
              for (var i = 0; i < players.length; i++)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: PremiumCard(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    radius: 16,
                    child: Row(
                      children: [
                        Container(width: 28, height: 28, alignment: Alignment.center, decoration: BoxDecoration(color: c.card2, shape: BoxShape.circle), child: Text('${i + 1}', style: TextStyle(color: c.text, fontWeight: FontWeight.w800))),
                        const SizedBox(width: 12),
                        Expanded(child: Text(players[i], style: TextStyle(color: c.text, fontWeight: FontWeight.w700))),
                        StatusBadge(label: i == 4 ? 'WK' : 'BAT', color: i == 4 ? const Color(0xff3b82f6) : c.cyan, filled: true),
                        const SizedBox(width: 8),
                        StatusBadge(label: 'Playing XI', color: c.success, filled: true),
                      ],
                    ),
                  ),
                ),
              const SizedBox(height: 12),
              Text('BENCH', style: TextStyle(color: c.cyan, fontWeight: FontWeight.w800, fontSize: 18)),
              const SizedBox(height: 10),
              Wrap(spacing: 10, runSpacing: 10, children: const [PillChip('Will Young'), PillChip('Lockie Ferguson'), PillChip('Michael Bracewell')]),
            ],
          ),
        )
      ],
    );
  }
}

